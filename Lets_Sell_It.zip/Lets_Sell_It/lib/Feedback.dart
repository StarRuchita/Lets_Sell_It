import 'dart:collection';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';

class MyFeedback extends StatefulWidget{

  String currentEmail;
  MyFeedback(this.currentEmail);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _MyFeedback(currentEmail);
  }

}

class _MyFeedback extends State<MyFeedback>{
  String feedback,currentEmail;
  var _formKey=GlobalKey<FormState>();

  _MyFeedback(this.currentEmail);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: new IconButton(
            icon: new Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }
        ),
        title: Text("Feedback",style: TextStyle(color: Colors.white),),backgroundColor: Colors.yellow[700],),
      body: Center(
        child: Padding(padding: EdgeInsets.only(top: 50,left: 20,right: 20),

          child: Form(
            key: _formKey,
            child:Column(
              children: <Widget>[
                Text("Feel free to drop us your feedback.",
                  style: TextStyle(color: Colors.white,fontSize: 20),
                ),

                Theme(
                  data: ThemeData(
                      hintColor: Colors.blue
                  ),
                  child: Padding(padding: EdgeInsets.only(top: 30),
                    child: TextFormField(
                      validator: (value){
                        if(value.isEmpty){
                          return "Please write a Feedback";
                        }else{
                          feedback=value;
                        }
                        return null;
                      },
                      style: TextStyle(color: Colors.white),

                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.symmetric(vertical: 40.0),
                        labelText: "Write your Feedback here..",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                        ),

                        disabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                        ),

                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                        ),

                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                        ),

                      ),
                    ),
                  ),
                ),


                Padding(
                    padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                    child: RaisedButton(

                      onPressed: () {
                        sendFeedback();
                        Fluttertoast.showToast(
                            msg: "Thank you for your feedback ",
                            gravity: ToastGravity.CENTER,
                            toastLength: Toast.LENGTH_LONG,
                            timeInSecForIosWeb: 2
                        );
                        Navigator.pushReplacement(context, MaterialPageRoute(
                            builder: (BuildContext context) => MyFeedback(currentEmail)));
                      },
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: Colors.yellow[700],
                      child: Text("Send Feedback",style: TextStyle(color: Colors.white,
                          fontWeight: FontWeight.bold,fontSize: 20),),
                      padding: EdgeInsets.all(10),
                    )
                )
              ],
            ),
          ),


        ),
      ),
    );
  }
  Future<void> sendFeedback() async {
    var now = new DateTime.now();
    var formatter = new DateFormat('dd-MM-yyyy');
    String formattedDate = formatter.format(now);
    if (_formKey.currentState.validate()) {
      DatabaseReference databaseReference = FirebaseDatabase.instance.reference().child("Feedback");
      String uploadId = databaseReference.push().key;
      HashMap map = new HashMap();
      map['Date'] = formattedDate;
      map["Email"] = (currentEmail).toString();
      map["Feedback"] = feedback;
      databaseReference.child(uploadId).set(map);
    }
  }
}