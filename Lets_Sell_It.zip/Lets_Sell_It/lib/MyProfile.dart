import 'dart:async';
import 'package:path/path.dart' as Path;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'Data.dart';
import 'EditDetails.dart';
import 'ProductDetails.dart';


class  MyProfile extends StatefulWidget {
  String currentEmail;
  MyProfile(this.currentEmail);
  @override
  _State createState() => _State(currentEmail);
}

class _State extends State<MyProfile> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  FirebaseUser user;
  String currentEmail;

  List<Data> dataList = [];

  _State(this.currentEmail);

  @override
  void initState() {
    super.initState();
    DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
    referenceData.once().then((DataSnapshot dataSnapShot){
      dataList.clear();
      var keys = dataSnapShot.value.keys;
      var values = dataSnapShot.value;

      for(var key in keys){
        Data data = new Data(
            values [key]['imgUrl0'],
            values [key]['imgUrl1'],
            values [key]['imgUrl2'],
            values [key]['imgUrl3'],
            values[key]["name"],
            values[key]["material"],
            values[key]["subCategory"],
            values[key]["price"],
            values[key]["adder"],
            key
        );
        if(data.adder.contains(currentEmail))
          dataList.add(data);

      }
      Timer(Duration(seconds: 1),(){
        setState(() {

        });
      });
    });

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: new IconButton(
            icon: new Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }),
        backgroundColor: Colors.yellow[700],
      ),
      body: Container(
        constraints: BoxConstraints(
          maxHeight: double.infinity,
        ),
        child: dataList.length == 0 ? Center(child: Text("No Data Available",style: TextStyle(fontSize: 30,color: Colors.black),)) :
        GridView.builder(
            itemCount: dataList.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2),
            itemBuilder: (_, index) {
              return CardUI(dataList[index].imgUrl0,dataList[index].imgUrl1,dataList[index].imgUrl2,dataList[index].imgUrl3, dataList[index].name,
                  dataList[index].material,dataList[index].subCategory, dataList[index].price,dataList[index].adder,dataList[index].uploadid,index);
            }
        ),
      ),
    );
  }
  Widget CardUI(String imgUrl0,String imgUrl1,String imgUrl2,String imgUrl3, String name, String material,String subCategory ,String price,String adder, String uploadId, int index) {
    return InkWell(
      onTap: (){
        Navigator.of(context).push(MaterialPageRoute(builder: (context) => ProductDetails(
          product_details_name: name,
          product_details_picture0: imgUrl0,
          product_details_picture1: imgUrl1,
          product_details_picture2: imgUrl2,
          product_details_picture3: imgUrl3,
          product_details_price: price,
          product_details_adder: adder,
        )));
      },
      child: Card(
        elevation: 1.5,
        margin: EdgeInsets.all(3),
        color: Colors.yellow[700],
        child: Container(
          color: Colors.white,
          margin: EdgeInsets.all(1),
          padding: EdgeInsets.all(1),
          child: Column(
            children: <Widget>[
              Image.network(imgUrl0,fit: BoxFit.cover,height: 60,width: 60,),
              SizedBox(height: 1,),
              Text(name,style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),),
              SizedBox(height: 1,),
              Container(
                width: double.infinity,
                child: Text("Price : "+price,style: TextStyle(color: Colors.red,fontSize: 10,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: (){
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text(
                                'Delete Product',
                                style: TextStyle(color: Colors.red),
                              ),
                              content: Text("Are you sure to delete this product?"),
                              actions: [
                                FlatButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text(
                                      'No',
                                      style: TextStyle(color: Colors.red),
                                    )),
                                FlatButton(
                                    onPressed: () {
                                      deleteMatch(uploadId);
                                      Navigator.pushReplacement(context, MaterialPageRoute(
                                          builder: (BuildContext context)=>MyProfile(currentEmail)));
                                    },
                                    child: Text(
                                      'Yes',
                                      style: TextStyle(color: Colors.green),
                                    ))
                              ],
                            );
                          });
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: (){
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text(
                                'Edit Product',
                                style: TextStyle(color: Colors.red),
                              ),
                              content: Text("Are you sure to Edit Details of this product?"),
                              actions: [
                                FlatButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text(
                                      'No',
                                      style: TextStyle(color: Colors.red),
                                    )),
                                FlatButton(
                                    onPressed: () {
                                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => Edit(currentEmail,uploadId,name,material,subCategory,price,imgUrl0,imgUrl1,imgUrl2,imgUrl3,adder)));
                                    },
                                    child: Text(
                                      'Yes',
                                      style: TextStyle(color: Colors.green),
                                    ))
                              ],
                            );
                          });
                    },
                  ),
                ],
              ),

            ],
          ),
        ),
      ),
    );
  }

  Future<void> deleteMatch(id) async {
    FirebaseDatabase.instance.reference().child("Data").child(id).remove();
  }

}


