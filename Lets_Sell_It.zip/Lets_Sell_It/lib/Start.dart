import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:lsit_new/Login.dart';
import 'HomePage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'SignUp.dart';

class Start extends StatefulWidget {
  @override
  _StartState createState() => _StartState();
}

class _StartState extends State<Start> {

  final FirebaseAuth _auth = FirebaseAuth.instance;
  checkAuthentification() async
  {

    _auth.onAuthStateChanged.listen((user) {

      if(user!= null)
      {
        print(user);

        Navigator.pushReplacement(context, MaterialPageRoute(

            builder: (context)=>HomePage(user.email)));
      }

    });
  }
  @override
  void initState()
  {
    super.initState();
    this.checkAuthentification();
  }

  Future<bool> _onBackPressed() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Are you sure?'),
            content: Text('You are going to exit the application!!'),
            actions: <Widget>[
              FlatButton(
                child: Text('NO'),
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
              ),
              FlatButton(
                child: Text('YES'),
                onPressed: () {
                  if (Platform.isAndroid) {
                    SystemNavigator.pop();
                  } else if (Platform.isIOS) {
                    exit(0);
                  }
                },
              ),
            ],
          );
        });
  }


  bool signInState = false;
  static FirebaseAuth auth= FirebaseAuth.instance;
  GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);
  googleSignIn()async{
    GoogleSignInAccount signInAccount = await _googleSignIn.signIn();
    GoogleSignInAuthentication signInAuthentication = await signInAccount.authentication;
    AuthCredential credential = GoogleAuthProvider.getCredential(idToken: signInAuthentication.idToken, accessToken: signInAuthentication.accessToken);
    FirebaseUser user = (await auth.signInWithCredential(credential)).user;
    print(user);

    setState(() {
      signInState = true;
    });
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context)=>HomePage(user.email.toString())));

  }

  navigateToLogin()async{

    Navigator.push(context, MaterialPageRoute(builder: (context)=> Login()));
  }

  navigateToRegister()async{

    Navigator.push(context, MaterialPageRoute(builder: (context)=> SignUp()));
  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Container(
          child: Column(
            children: <Widget>[

              SizedBox(height: 35.0),
              Container(
                height: 100,

                child: Image(image: AssetImage("images/logo_lsit.png"),
                  fit: BoxFit.contain,
                ),
              ),

              SizedBox(height : 20),

              RichText(

                  text: TextSpan(
                      text: 'Welcome to ', style: TextStyle(
                      fontSize: 25.0,
                      fontWeight: FontWeight.bold,

                  ),

                      children: <TextSpan>[
                        TextSpan(
                            text: 'LSiT', style: TextStyle(
                            fontSize: 30.0,
                            fontWeight: FontWeight.bold,
                            color:Colors.yellow[700])
                        )
                      ]
                  )
              ),
              SizedBox(height: 10.0),

              Text('Sell Reusable things in just one click',style: TextStyle(color:Colors.white),),

              SizedBox(height: 30.0),


              Row( mainAxisAlignment: MainAxisAlignment.center,

                children: <Widget>[

                  RaisedButton(
                      padding: EdgeInsets.only(left:30,right:30),

                      onPressed: navigateToLogin,
                      child: Text('LOGIN',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),),

                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      color: Colors.yellow[700]
                  ),

                  SizedBox(width:20.0),

                  RaisedButton(
                      padding: EdgeInsets.only(left:30,right:30),

                      onPressed: navigateToRegister,
                      child: Text('REGISTER',style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),),

                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      color: Colors.yellow[700]
                  ),

                ],
              ),


              SizedBox(height : 20.0),

              SignInButton(
                Buttons.Google,
                text: "Sign in with Google",
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                onPressed: googleSignIn,
              )
            ],
          ),
        ),

      ),
    );
  }

 


}