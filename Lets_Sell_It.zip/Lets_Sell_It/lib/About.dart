import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AboutUs extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _AboutUs();
  }
}

class _AboutUs extends State<AboutUs>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          leading: new IconButton(
              icon: new Icon(Icons.arrow_back_ios),
              onPressed: () {
                Navigator.pop(context);
              }
          ),
          backgroundColor: Colors.yellow[700],),
        body: ListView(
          children: <Widget>[
            Container(
              width: double.infinity,
              height: 150,
              child: Padding(
                padding: EdgeInsets.all(5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 35,),
                    Text("About Us", style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold, fontSize: 45),),
                  ],
                ),
              ),
              decoration: BoxDecoration(borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(250)),
                  
                color: Colors.yellow[700],
              ),
            ),
          ],
        )
    );
  }
}