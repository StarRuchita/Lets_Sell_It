import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:lsit_new/HomePage.dart';
import 'ForgotScreen.dart';
import 'SignUp.dart';
import 'Start.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {


  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String _email, _password;

  login()async
  {
    if(_formKey.currentState.validate())
    {

      _formKey.currentState.save();

      try{
        FirebaseUser user = (await _auth.signInWithEmailAndPassword(email: _email, password: _password)) as FirebaseUser;
        if(user!=null) {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => HomePage(_email.toString())));
        }
      }

      catch(e)
      {
        showError(e.message);
        print(e);
      }

    }
  }

  showError(String errormessage){

    showDialog(

        context: context,
        builder: (BuildContext context)
        {
          return AlertDialog(

            title: Text('ERROR'),
            content: Text(errormessage),

            actions: <Widget>[
              FlatButton(

                  onPressed: (){
                    Navigator.of(context).pop();
                  },


                  child: Text('OK'))
            ],
          );
        }


    );

  }

  navigateToSignUp()async
  {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> SignUp()));
  }

  Future<bool> _onBackPressed() {
    return Future.value(true);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: (){
        if(_onBackPressed()==true)
          {
            Navigator.pushReplacement(context, MaterialPageRoute(
                builder: (BuildContext context)=>Start()
            ));
          }
      },
      child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            iconTheme: IconThemeData(color: Colors.white),
            leading: new IconButton(
                icon: new Icon(Icons.arrow_back_ios),
                onPressed: () {
                  Navigator.pop(context);
                }
            ),
            ),
          body: SingleChildScrollView(
            child: Container(
              child: Column(
                children: <Widget>[
                  Container(
                    width: double.infinity,
                    height: 100,
                    child: Padding(
                      padding: EdgeInsets.all(5),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(height: 30,),
                          Text("Log In", style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold, fontSize: 35),),
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(250)),

                      color: Colors.yellow[700],
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    padding: EdgeInsets.only(top:20,left: 20,right: 20),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: <Widget>[
                          Container(
                            child: Theme(
                              data: ThemeData(hintColor:Colors.white),
                              child: TextFormField(
                                  style: TextStyle(color: Colors.white),
                                  validator: (input)
                                  {
                                    if(input.isEmpty)
                                      return 'Enter Email';
                                  },
                                  decoration: InputDecoration(
                                    labelStyle: TextStyle(color: Colors.white),
                                      labelText: 'Email',
                                      prefixIcon:Icon(Icons.email,color: Colors.white,),
                                      border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(15),
                                          borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                         ),

                                      disabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(15),
                                          borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                      ),

                                      enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(15),
                                          borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                      ),

                                      focusedBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(15),
                                          borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                      ),
                                  ),

                                  onSaved: (input) => _email = input


                              ),
                            ),
                          ),
                          SizedBox(height: 10,),
                          Container(

                            child: Theme(
                              data: ThemeData(hintColor:Colors.white),
                              child: TextFormField(
                                  style: TextStyle(color: Colors.white),
                                  validator: (input)
                                  {
                                    if(input.length < 6)

                                      return 'Provide Minimum 6 Character';
                                  },

                                  decoration: InputDecoration(
                                    labelStyle: TextStyle(color: Colors.white),
                                    labelText: 'Password',
                                    prefixIcon:Icon(Icons.lock,color: Colors.white,),
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                    ),

                                    disabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                    ),

                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                    ),

                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(15),
                                        borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                    ),
                                  ),
                                  obscureText: true,


                                  onSaved: (input) => _password = input


                              ),
                            ),
                          ),
                          SizedBox(height:20),

                          RaisedButton(
                            padding: EdgeInsets.fromLTRB(70,10,70,10),
                            onPressed: login,
                            child: Text('LOGIN',style: TextStyle(

                                color: Colors.white,
                                fontSize: 20.0,
                                fontWeight: FontWeight.bold

                            )),

                            color: Colors.yellow[700],
                            shape: RoundedRectangleBorder(

                              borderRadius: BorderRadius.circular(20.0),
                            ),

                          )
                        ],
                      ),

                    ),
                  ),
                  SizedBox(height: 10,),
                  GestureDetector(
                    child: Text('Create an Account?',style: TextStyle(color: Colors.blue),),
                    onTap: navigateToSignUp,
                  ),
                  Padding(padding: EdgeInsets.all(20),
                      child: Container(
                        width: double.infinity,
                        child: InkWell(
                          onTap: (){
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context)=> ForgotScreen()));
                          },
                          child: Text("Forgot password ?",style: TextStyle(color: Colors.blue),
                            textAlign: TextAlign.center,),
                        ),
                      )
                  ),

                ],
              ),
            ),
          )

      ),
    );
  }
}
