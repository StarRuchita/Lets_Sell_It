class ReviewData{
  String Date,Email,Feedback,uploadId;
  ReviewData(this.Date,this.Email,this.Feedback,this.uploadId);
}
