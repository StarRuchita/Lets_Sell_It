class Data{
  String imgUrl0,imgUrl1,imgUrl2,imgUrl3,name,material,subCategory,price,adder,uploadid;
  Data(this.imgUrl0,this.imgUrl1,this.imgUrl2,this.imgUrl3,this.name,this.material,this.subCategory,this.price,this.adder,this.uploadid);
}
