import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'ReviewData.dart';
import 'ReviewDetails.dart';

class DeleteReviews extends StatefulWidget {
  @override
  _DeleteReviewsState createState() => _DeleteReviewsState();
}

class _DeleteReviewsState extends State<DeleteReviews> {

  List<ReviewData> dataList = [];

  @override
  void initState() {
    super.initState();
    DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Feedback");
    referenceData.once().then((DataSnapshot dataSnapShot){
      dataList.clear();
      var keys = dataSnapShot.value.keys;
      var values = dataSnapShot.value;

      for(var key in keys){
        ReviewData data = new ReviewData(
            values [key]['Date'],
            values [key]['Email'],
            values [key]['Feedback'],
          key
        );
        dataList.add(data);
      }
      Timer(Duration(seconds: 1),(){
        setState(() {

        });
      });
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: new IconButton(
            icon: new Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }
        ),
        title: Text("Delete Review",style: TextStyle(color: Colors.white),),backgroundColor: Colors.yellow[700],),
      body: Container(
        constraints: BoxConstraints(
          maxHeight: double.infinity,
        ),
        child: dataList.length == 0 ? Center(child: Text("No Reviews Available",style: TextStyle(fontSize: 30,color: Colors.black),)) :

        ListView.separated(
          separatorBuilder: (context, index) => Divider(
            color: Colors.black,
          ),
          itemCount: dataList.length,
          itemBuilder: (context, index) => Padding(
            padding: EdgeInsets.all(2.0),
            child: ListUI(dataList[index].Date,dataList[index].Email,dataList[index].Feedback,dataList[index].uploadId,index),
          ),
        ),
      ),
    );
  }
  Widget ListUI(String Date,String Email,String Feedback,String uploadId, int index) {
    return ListTile(
      contentPadding: EdgeInsets.symmetric(vertical: 1),
      hoverColor: Colors.black12,
      tileColor: Colors.white,
      onTap: (){
        Navigator.push(context, MaterialPageRoute(
            builder: (BuildContext context)=>ReviewDetails(Date,Email,Feedback)
        ));
      },
      title: Text(Feedback, style: new TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.normal,
            fontSize: 15.0),
      ),
      /*subtitle: Text(Email, style: new TextStyle(
          color: Colors.black26,
          fontWeight: FontWeight.normal,
          fontSize: 10.0),
      ),*/
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          IconButton(
            icon: Icon(
              Icons.delete_outline,
              size: 20.0,
              color: Colors.red,
            ),
            onPressed: () {
              //   _onDeleteItemPressed(index);
              showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                    title: Text('Delete Review', style: TextStyle(color: Colors.red),),
                    content: Text("Are you sure to delete this Review?"),
                    actions: [
                      FlatButton(
                        onPressed: () {Navigator.of(context).pop();},
                        child: Text('No', style: TextStyle(color: Colors.red),)
                      ),
                      FlatButton(
                        onPressed: () {
                          deleteReview(uploadId);
                          Fluttertoast.showToast(
                              msg: "Deleted Successfully",
                              gravity: ToastGravity.CENTER,
                              toastLength: Toast.LENGTH_LONG,
                              timeInSecForIosWeb: 2
                          );
                          Navigator.pushReplacement(context, MaterialPageRoute(
                          builder: (BuildContext context)=>DeleteReviews()));
                        },
                        child: Text('Yes', style: TextStyle(color: Colors.green),)
                      )
                    ],
                  );
              });
            },
          ),
        ],
      ),
    );
  }

  Future<void> deleteReview(id) async {
    FirebaseDatabase.instance.reference().child("Feedback").child(id).remove();
  }


}
