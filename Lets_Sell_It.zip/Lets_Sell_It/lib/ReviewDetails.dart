import 'package:flutter/material.dart';

class ReviewDetails extends StatefulWidget {
  String Date,Email,Feedback;
  ReviewDetails(this.Date,this.Email,this.Feedback);
  @override
  _ReviewDetailsState createState() => _ReviewDetailsState(Date,Email,Feedback);
}

class _ReviewDetailsState extends State<ReviewDetails> {

  String Date,Email,Feedback;
  _ReviewDetailsState(this.Date,this.Email,this.Feedback);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.1,
        backgroundColor: Colors.orange,
        title: Text('LSit',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
        iconTheme: new IconThemeData(color: Colors.white),
        leading: new IconButton(
            icon: new Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }
        ),
      ),
      body: Column(
        children: <Widget>[
          SizedBox(height: 10,),
          Container(
            width: double.infinity,
            height: 50,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 5,),
                  Text("Review Date : "+widget.Date, style: TextStyle(color: Colors.black54,fontWeight: FontWeight.bold, fontSize: 15),),
                ],
              ),
            ),
          ),
          Divider(),
          Container(
            width: double.infinity,
            height: 50,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 5,),
                  Text("Reviewer Email Id : "+widget.Email, style: TextStyle(color: Colors.black54,fontWeight: FontWeight.bold, fontSize: 15),),
                ],
              ),
            ),
          ),
          Divider(),
          Container(
            width: double.infinity,
            height: 50,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 5,),
                  Text("Feedback : "+widget.Feedback, style: TextStyle(color: Colors.black54,fontWeight: FontWeight.bold, fontSize: 15),),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
