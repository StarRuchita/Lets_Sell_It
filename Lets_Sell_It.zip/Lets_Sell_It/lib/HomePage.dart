import 'dart:async';
import 'dart:io';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:lsit_new/DeleteReview.dart';
import 'package:lsit_new/MyProfile.dart';
import 'package:lsit_new/Start.dart';
import 'About.dart';
import 'AddProduct.dart';
import 'Data.dart';
import 'MyFavorite.dart';
import 'ProductDetails.dart';
import 'Feedback.dart';

class HomePage extends StatefulWidget {
  String currentEmail,_image;
  HomePage(this.currentEmail);

  @override
  _HomePageState createState() => _HomePageState(currentEmail);
}

class _HomePageState extends State<HomePage> {

  final List<String> Searching_words = [];

  List<Data> dataList = [];
  List<bool> favList = [];
  bool SearchState = false;
  String currentEmail,_image;
  FirebaseAuth _auth = FirebaseAuth.instance;
  bool isloggedin= false;

  _HomePageState(this.currentEmail);

  checkAuthentification() async{

    _auth.onAuthStateChanged.listen((user) {

      if(user == null)
      {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> Start()));
      }
    });
  }

  signOut()async{

    _auth.signOut();
  }

  Future<bool> _onBackPressed() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Are you sure?'),
            content: Text('You are going to exit the application!!'),
            actions: <Widget>[
              FlatButton(
                child: Text('NO'),
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
              ),
              FlatButton(
                child: Text('YES'),
                onPressed: () {
                  if (Platform.isAndroid) {
                    SystemNavigator.pop();
                  } else if (Platform.isIOS) {
                    exit(0);
                  }
                },
              ),
            ],
          );
        });
  }

  @override
  void initState(){
    super.initState();
    this.checkAuthentification();

    DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
    referenceData.once().then((DataSnapshot dataSnapShot){
      dataList.clear();
      favList.clear();
      var keys = dataSnapShot.value.keys;
      var values = dataSnapShot.value;

      for(var key in keys){
        Data data = new Data(
            values[key]["imgUrl0"],
            values[key]["imgUrl1"],
            values[key]["imgUrl2"],
            values[key]["imgUrl3"],
            values[key]["name"],
            values[key]["material"],
            values[key]["subCategory"],
            values[key]["price"],
            values[key]["adder"],
            key
        );
        Searching_words.add(data.material);
        Searching_words.add(data.subCategory);
        Searching_words.add(data.name);
        Searching_words.add(data.adder);


        dataList.add(data);
        _auth.currentUser().then((value) {
          DatabaseReference reference = FirebaseDatabase.instance.reference().child("Data").child(key).child("Fav")
              .child(value.uid).child("state");
          reference.once().then((DataSnapshot snapShot){
            if(snapShot.value!=null){
              if(snapShot.value=="true"){
                favList.add(true);
              }else{
                favList.add(false);
              }
            }else{
              favList.add(false);
            }
          });
        });

      }
      Timer(Duration(seconds: 1),(){
        setState(() {

        });
      });
    });


  }
  @override
  Widget build(BuildContext context) {

    Widget image_carousel = new Container(
      height: 200.0,
      child: new Carousel(
          boxFit: BoxFit.cover,
          images: [
            AssetImage('images/books.jpg'),
            AssetImage('images/bicycle.jpg'),
            AssetImage('images/Capture.PNG'),
            AssetImage('images/mobile.jpg'),
            AssetImage('images/headphones.jpg'),
            AssetImage('images/watch.jpg'),
            AssetImage('images/sports.jpg'),
          ],
          autoplay: true,
          dotSize: 6.0,
          indicatorBgPadding: 3.0,
          animationCurve: Curves.fastOutSlowIn,
          animationDuration: Duration(microseconds: 1000)
      ),
    );
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0.1,
          iconTheme: IconThemeData(
            color: Colors.white
          ),

          backgroundColor: Colors.yellow[700],
          title: !SearchState?Text("Home",style: TextStyle(color: Colors.white),):
          Container(
            padding: const EdgeInsets.all(20.0),
            child: AutoSearchInput(
              data: searching_words,
              maxElementsToDisplay: 5,
              onItemTap: (index) {
                SearchMethod(searching_words[index]);
              },
            ),
          ),
          actions: <Widget>[
            !SearchState ? IconButton(icon: Icon(Icons.search,color: Colors.white,),onPressed: (){
              setState(() {
                SearchState = !SearchState;
              });
            },) :
            IconButton(icon: Icon(Icons.cancel,color: Colors.white,),onPressed: (){
              setState(() {
                SearchState = !SearchState;
              });
            },),

            FlatButton.icon(
              onPressed: (){
                signOut();
                Navigator.pushReplacement(context, MaterialPageRoute(
                    builder: (BuildContext context)=>Start()
                ));
              },
              icon: Icon(Icons.person,color: Colors.white,),
              label: Text("Log out",style: TextStyle(color: Colors.white),),
            )
          ],
        ),
        drawer: (currentEmail == "ruchitanagar17@gmail.com")? Drawer(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: double.infinity,
                height: 170,
                color: Colors.black,
                child: Column(
                  children: <Widget>[
                    Padding(padding: EdgeInsets.only(top: 30)),
                    CircleAvatar(
                      child: ClipOval(
                        child: Center(
                          child: _image == null
                              ? Icon(Icons.person, color: Colors.grey.shade700, size: 100,) : NetworkImage(_image,),
                        ),
                      ),

                      radius: 50,
                      backgroundColor: Colors.grey.shade300,
                    ),
                    SizedBox(height: 10,),
                    Text(currentEmail, style: TextStyle(color: Colors.white),),
                  ],
                ),
              ),
              ListTile(
                title: Text("Sell Product"),
                leading: Icon(Icons.cloud_upload,color: Colors.blue,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>AddProduct(currentEmail)
                  ));
                },
              ),
              ListTile(
                title: Text("My Favorite"),
                leading: Icon(Icons.favorite,color: Colors.red,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>MyFavorite()
                  ));
                },
              ),

              ListTile(
                title: Text("Products Added"),
                leading: Icon(Icons.add,color: Colors.black,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>MyProfile(currentEmail)
                  ));
                },
              ),
              Divider(),
              ListTile(
                title: Text("Feedback"),
                leading: Icon(Icons.feedback),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>MyFeedback(currentEmail)
                  ));
                },
              ),
              Divider(),
              ListTile(
                title: Text("About Us"),
                leading: Icon(Icons.email),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>AboutUs()
                  ));
                },
              ),
              Divider(),
              ListTile(
                  title: Text("App Reviews"),
                  leading: Icon(Icons.email),
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (BuildContext context)=>DeleteReviews()));
                  }
              ),
            ],
          ),
        ):Drawer(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: double.infinity,
                height: 170,
                color: Colors.black,
                child: Column(
                  children: <Widget>[
                    Padding(padding: EdgeInsets.only(top: 30)),
                    CircleAvatar(
                      child: ClipOval(
                        child: Center(
                          child: _image == null
                              ? Icon(Icons.person, color: Colors.grey.shade700, size: 100,) : NetworkImage(_image,),
                        ),
                      ),

                      radius: 50,
                      backgroundColor: Colors.grey.shade300,
                    ),
                    SizedBox(height: 10,),
                    Text(currentEmail, style: TextStyle(color: Colors.white),),
                  ],
                ),
              ),
              ListTile(
                title: Text("Sell Product"),
                leading: Icon(Icons.cloud_upload,color: Colors.blue,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>AddProduct(currentEmail)
                  ));
                },
              ),
              ListTile(
                title: Text("My Favorite"),
                leading: Icon(Icons.favorite,color: Colors.red,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>MyFavorite()
                  ));
                },
              ),

              ListTile(
                title: Text("Products Added"),
                leading: Icon(Icons.add,color: Colors.black,),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>MyProfile(currentEmail)
                  ));
                },
              ),
              Divider(),
              ListTile(
                title: Text("Feedback"),
                leading: Icon(Icons.feedback),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>MyFeedback(currentEmail)
                  ));
                },
              ),
              Divider(),
              ListTile(
                title: Text("About Us"),
                leading: Icon(Icons.email),
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context)=>AboutUs()
                  ));
                },
              ),
              Divider(),
            ],
          ),
        ),

        body: SingleChildScrollView(
          child: Container(
            child: Column(
                  children: <Widget>[
                    image_carousel,
                    Padding(padding: const EdgeInsets.all(5.0),
                      child: Text(
                          'Categories'
                      ),
                    ),
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                  dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child:Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                                color: Colors.black,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.yellow[700],width: 3)
                            ),
                            child: Center(child: Text("All",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),)),

                          ),

                        ),
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                if(data.material.toLowerCase().contains("book"))
                                  dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage('images/book_logo.jpg'),
                                  fit: BoxFit.fill
                              ),
                            ),

                          ),
                        ),
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                if(data.material.toLowerCase().contains("bicycle"))
                                  dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage('images/cycle_logo.png'),
                                  fit: BoxFit.fill
                              ),
                            ),

                          ),
                        ),
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                if(data.material.toLowerCase().contains("laptop"))
                                   dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage('images/Laptop_logo.png'),
                                  fit: BoxFit.fill
                              ),
                            ),

                          ),
                        ),
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                if(data.material.toLowerCase().contains("mobile"))
                                  dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage('images/mobile_logo.png'),
                                  fit: BoxFit.fill
                              ),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                if(data.material.toLowerCase().contains("watch"))
                                  dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage('images/watch.png'),
                                  fit: BoxFit.fill
                              ),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
                            referenceData.once().then((DataSnapshot dataSnapShot){
                              dataList.clear();
                              var keys = dataSnapShot.value.keys;
                              var values = dataSnapShot.value;

                              for(var key in keys){
                                Data data = new Data(
                                    values[key]["imgUrl0"],
                                    values[key]["imgUrl1"],
                                    values[key]["imgUrl2"],
                                    values[key]["imgUrl3"],
                                    values[key]["name"],
                                    values[key]["material"],
                                    values[key]["subCategory"],
                                    values[key]["price"],
                                    values[key]["adder"],
                                    key
                                );
                                    if(data.material.toLowerCase().contains("sports and fitness"))
                                  dataList.add(data);
                              }
                              Timer(Duration(seconds: 1),(){
                                setState(() {

                                });
                              });
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(0.0),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: AssetImage('images/sports.png'),
                                  fit: BoxFit.fill
                              ),
                            ),
                          ),
                        ),

                      ],
                    ),

                  ),

                    Padding(padding: const EdgeInsets.all(5.0),
                      child: Text(
                          'Products'
                      ),
                    ),
                    //Grid View
                    Container(
                      constraints: BoxConstraints(
                        maxHeight: 400,
                        minHeight: 250,
                      ),
                      child: dataList.length == 0 ? Center(child: Text("No Data Available",style: TextStyle(fontSize: 30,color: Colors.black),)) :
                      GridView.builder(
                          itemCount: dataList.length,
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2),
                          itemBuilder: (_, index) {
                            return CardUI(dataList[index].imgUrl0,dataList[index].imgUrl1,dataList[index].imgUrl2,dataList[index].imgUrl3, dataList[index].name,
                                dataList[index].material, dataList[index].price,dataList[index].adder,dataList[index].uploadid,index);
                          }
                      ),
                    )
                  ],
                ),
          ),
        ),
      ),
    );
  }

  Widget CardUI(String imgUrl0,String imgUrl1,String imgUrl2,String imgUrl3, String name, String material, String price,String adder, String uploadId, int index) {
    return Card(
        elevation: 1,
        margin: EdgeInsets.all(2),
        color: Colors.yellow[700],
        child: Container(
          color: Colors.white,
          margin: EdgeInsets.all(1),
          padding: EdgeInsets.all(1),
          child: Column(
            children: <Widget>[
              Image.network(imgUrl0,fit: BoxFit.cover,height: 70,width: 70,),
              SizedBox(height: 1,),
              Text(name,style: TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.bold),),
              SizedBox(height: 1,),
               Text("Rs : "+price,style: TextStyle(color: Colors.red,fontSize: 10,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
              SizedBox(height: 1,),
              Row(
                children: <Widget>[
                  favList[index]?
                  IconButton(icon: Icon(Icons.favorite,color: Colors.red,), onPressed: () {
                    _auth.currentUser().then((value) {
                      DatabaseReference favRef = FirebaseDatabase.instance.reference().child("Data").child(uploadId).child("Fav").child(value.uid).child("state");
                      favRef.set("false");
                      setState(() {
                        FavoriteFunc();
                      });
                    });
                  }):
                  IconButton(icon: Icon(Icons.favorite_border), onPressed: (){
                    _auth.currentUser().then((value) {
                      DatabaseReference favRef = FirebaseDatabase.instance.reference().child("Data").child(uploadId).child("Fav")
                          .child(value.uid).child("state");
                      favRef.set("true");

                      setState(() {
                        FavoriteFunc();
                      });

                    });
                  }),
                  RaisedButton(
                    child: Text('View'),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0)),
                    color: Colors.yellow[700],
                    textColor: Colors.white,
                    onPressed: () {
                      Route route = MaterialPageRoute(builder: (context) => ProductDetails(product_details_name: name,
                        product_details_picture0: imgUrl0,
                        product_details_picture1: imgUrl1,
                        product_details_picture2: imgUrl2,
                        product_details_picture3: imgUrl3,
                        product_details_price: price,
                        product_details_adder: adder,
                        upload_id:uploadId,));
                      Navigator.push(context, route).then(onGoBack);

                    },
                  ),

                ],
              )
            ],
          ),
        ),
      );
  }

  void FavoriteFunc() {
    DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
    referenceData.once().then((DataSnapshot dataSnapShot) {
      favList.clear();

      var keys = dataSnapShot.value.keys;

      for (var key in keys) {
        _auth.currentUser().then((value) {
          DatabaseReference reference = FirebaseDatabase.instance.reference()
              .child("Data").child(key).child("Fav")
              .child(value.uid)
              .child("state");
          reference.once().then((DataSnapshot snapShot) {
            if (snapShot.value != null) {
              if (snapShot.value == "true") {
                favList.add(true);
              } else {
                favList.add(false);
              }
            } else {
              favList.add(false);
            }
          });
        });
      }
      Timer(Duration(seconds: 1), (){
        setState(() {
          //
        });
      });

    });
  }


  void SearchMethod(String text) {
    DatabaseReference searchRef = FirebaseDatabase.instance.reference().child("Data");
    searchRef.once().then((DataSnapshot snapShot){
      dataList.clear();
      var keys = snapShot.value.keys;
      var values = snapShot.value;

      for(var key in keys){
        Data data = new Data(
            values[key]["imgUrl0"],
            values[key]["imgUrl1"],
            values[key]["imgUrl2"],
            values[key]["imgUrl3"],
            values[key]['name'],
            values[key]['material'],
            values[key]["subCategory"],
            values[key]['price'],
            values[key]["adder"],
            key
        );
        if(data.name.toLowerCase().contains(text.toLowerCase()) | data.material.toLowerCase().contains(text.toLowerCase()) |
           data.adder.toLowerCase().contains(text.toLowerCase()) | data.subCategory.toLowerCase().contains(text.toLowerCase()))
        {
          dataList.add(data);
        }
      }
      Timer(Duration(seconds: 1),(){
        setState(() {

        });
      });
    });

  }

  onGoBack(dynamic value) {
    FavoriteFunc();
    setState(() {});
  }
}