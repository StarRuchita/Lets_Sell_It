import 'dart:async';
import 'dart:collection';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:lsit_new/HomePage.dart';
import 'package:multi_image_picker/multi_image_picker.dart';
import 'package:path_provider/path_provider.dart';

class AddProduct extends StatefulWidget {
  String currentEmail;
  AddProduct(this.currentEmail);
  @override
  _AddProductState createState() => _AddProductState(currentEmail);
}

class _AddProductState extends State<AddProduct> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String name, material, price,currentEmail,subCategary;
  List<Asset> images = List<Asset>();

  List<String> Categories = ['Accesories','Bicycle', 'Book','Computer and Laptop', 'Mobile', 'Tablet', 'Watch', 'Sports and Fitness'];
  List<String> AccesoriesCat = ['Mobile Charger', 'Earphone', 'Speakers', 'USB Cable', 'Laptop Charger', 'Mobile Cases and Covers', 'Power Bank',];
  List<String> MobileCat = ['Apple','Asus','Acer', 'Blackberry', 'Gionee', 'Honor', 'HPL', 'HTC', 'Huawei', 'IBall', 'Infinix', 'Itel', 'Lava', 'Lenovo', 'LG', 'Mi', 'Micromax', 'Motorola', 'Nokia', 'Oppo', 'Panasonic', 'Poco', 'Realme' 'Reliance', 'Samsung', 'Spice', 'Sony', 'Tecno', 'Vivo'];
  List<String> LaptopCat = ['Apple', 'Acer','Asus','Avita', 'Dell', 'HP', 'MI', 'Lenovo'];
  List<String> BiCycleCat = ['Atlas', 'Avon', 'BSA Ladybird', 'Btwin', 'Bianchi', 'Cannondale', 'Firefox ', 'Giant', 'GT', 'Hero', 'Hercules ', 'Huge ','Mach City', 'La Sovereign', 'Montra', 'Mongoose', 'Merida', 'Ridley ', 'Raleigh', 'Road Master', 'Scott', 'Schnell ', 'Specialized'];
  List<String> BookCat = ['Adventure', 'Art', 'cooking', 'Contemporary', 'Development', 'Guide', 'Health', 'History','Motivational', 'Mystery', 'Self-Development', 'Science Fiction', 'Subjective', 'Travel'];
  List<String> TabCat = ['Apple ipads', 'Asus', 'Ambrane', 'AOC', 'Celkon', 'Datawind', 'HCL', 'HP','Huawei', 'IBall', 'Intex','ISUN','Karbonn', 'Lava', 'Lenovo', 'Micromax', 'Microsoft','Nokia', 'Samsung', 'Sony', 'Spice', 'Toshiba','UNI', 'Xiaomi'];
  List<String> WatchCat = ['Adidas', 'Armani Exchange','Bentley', 'Casio', 'Chumbak', 'Citizen','Daniel Klein', 'Daniel Wellington','DIESEL', 'DKNY', 'Dressberry', 'Fastrack','Fossil', 'French Connection', 'GANT','Giordano', 'Guess', ' Karen Millen', 'Mini', 'Roadster', 'Rolex', 'Sonata','Tag Heuer','Ted Baker','Timex','Titan','Tommy Hilfiger'];
  List<String> SportsCat = ['Shuttlecocks','Bats','Nets','Racquets','Heart Rate Monitors','Waist Packs','Hydration Packs','Skipping Ropes','Gloves', 'Straps','Cricket Bat','Cricket Ball', 'Cricket Sets','Football','Air Pump','Tennis Ball','Tennis Racquets','Other'];
  List<String> SubCat = [];

  _AddProductState(this.currentEmail);

  Future<void> pickImages() async {
    List<Asset> resultList = List<Asset>();

    try {
      resultList = await MultiImagePicker.pickImages(
        maxImages: 4,
        enableCamera: true,
        selectedAssets: images,
        materialOptions: MaterialOptions(
          actionBarTitle: "LSiT",
        ),
      );
    } on Exception catch (e) {
      print(e);
    }
    setState(() {
      images = resultList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          leading: new IconButton(
              icon: new Icon(Icons.arrow_back_ios),
              onPressed: () {
                Navigator.pop(context);
              }
          ),
          backgroundColor: Colors.yellow[700]
      ),
      body: SingleChildScrollView(
        child: Column(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(left: 20,right: 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                      children: <Widget>[
                        SizedBox(height: 1,),
                        FlatButton(
                            onPressed: (){
                              pickImages();
                            },
                            child: Icon(Icons.add_a_photo,size: 50,color: Colors.yellow[700],)
                        ),
                        SizedBox(height: 10,),
                        Container(
                          height: 80,
                          decoration: BoxDecoration(
                            color: Colors.black26,
                          ),
                          child:GridView.count(
                            crossAxisCount: 4,
                            crossAxisSpacing: 4.0,
                            mainAxisSpacing: 8.0,
                            children: List.generate(images.length, (index) {
                              Asset asset = images[index];
                              return AssetThumb(
                                asset: asset,
                                width: 80,
                                height: 80,
                              );
                            }),
                          ),

                        ),
                        SizedBox(height: 10,),
                        Container(
                          child: Theme(
                            data: ThemeData(hintColor:Colors.blue),
                            child: TextFormField
                              (
                              style: TextStyle(color: Colors.black),
                              validator: (input)
                              {
                                if(input.isEmpty)
                                  return 'Enter Product Name';
                                else
                                  name=input;
                              },
                              decoration: InputDecoration(
                                labelStyle: TextStyle(color: Colors.black),
                                labelText: 'Product Name',
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                ),
                                disabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                ),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15),
                                    borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 10,),
                        Container(
                          child: Theme(
                            data: ThemeData(hintColor:Colors.blue),
                            child: TextFormField
                              (
                                style: TextStyle(color: Colors.black),
                                validator: (input)
                                {
                                  if(input.isEmpty)
                                    return 'Enter Price of Product';
                                  else
                                    price=input;
                                },
                                decoration: InputDecoration(
                                  labelStyle: TextStyle(color: Colors.black),
                                  labelText: 'Product Price',
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                  ),
                                  disabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                                  ),
                                ),
                                onSaved: (input) => price = input
                            ),
                          ),
                        ),
                        SizedBox(height: 10,),
                        Container(
                          child: DropdownButtonFormField<String>(
                            isExpanded: true,
                            value: material,
                            decoration: InputDecoration(
                              border:  OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),
                              disabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),

                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),
                            ),
                            hint: Text(
                              'Select Category',style: TextStyle(color: Colors.black),
                            ),
                            onChanged: (value) {
                              if(value=="Accesories")
                                {
                                  SubCat =List.from(AccesoriesCat);
                                }
                              else
                                {
                                  if(value=="Bicycle")
                                    {
                                      SubCat = List.from(BiCycleCat);
                                    }
                                  else
                                    {
                                      if(value=="Book")
                                      {
                                        SubCat = List.from(BookCat);
                                      }
                                      else
                                        {
                                          if(value=="Computer and Laptop")
                                            {
                                              SubCat = List.from(LaptopCat);
                                            }
                                          else
                                            {
                                              if(value=="Mobile")
                                                {
                                                  SubCat = List.from(MobileCat);
                                                }
                                              else
                                                {
                                                  if(value=="Tablet")
                                                    {
                                                      SubCat = List.from(TabCat);
                                                    }
                                                  else
                                                    {
                                                      if(value=="Watch")
                                                        {
                                                          SubCat = List.from(WatchCat);
                                                        }
                                                      else
                                                        {
                                                          if(value=="Sports and Fitness")
                                                            {
                                                              SubCat = List.from(SportsCat);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                }

                              setState(() {
                                subCategary=null;
                                material = value;
                              });
                            },
                            validator: (value){
                              if (value == null) {
                                return 'Category is required';
                              }
                              else
                                material=value;
                            },
                            items: Categories.map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                        SizedBox(height: 10,),
                        Container(
                          child: DropdownButtonFormField<String>(
                            isExpanded: true,
                            value: subCategary,
                            decoration: InputDecoration(
                              border:  OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),
                              disabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),

                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(color: Colors.yellow[700],width: 1)
                              ),
                            ),
                            hint: Text(
                              'Select Sub Category',style: TextStyle(color: Colors.black),
                            ),
                            onChanged: (scat) =>
                                setState(() => subCategary = scat),
                            validator: (scat){
                              if (scat == null) {
                                return 'Sub Category is required';
                              }
                              else
                                subCategary=scat;
                            },
                            items: SubCat.map<DropdownMenuItem<String>>((String scat) {
                              return DropdownMenuItem<String>(
                                value: scat,
                                child: Text(scat),
                              );
                            }).toList(),
                          ),
                        ),
                        SizedBox(height: 10,),

                        RaisedButton(
                          padding: EdgeInsets.fromLTRB(70,10,70,10),
                          onPressed: (){
                            if (images.isEmpty) {
                              Fluttertoast.showToast(
                                  msg: "Please Select Images of the product",
                                  gravity: ToastGravity.CENTER,
                                  toastLength: Toast.LENGTH_LONG,
                                  timeInSecForIosWeb: 2
                              );
                            } else {
                              if (_formKey.currentState.validate()) {
                                upload(images);
                              }
                            }
                          },
                          child: Text('Upload',style: TextStyle(
                              color: Colors.white,
                              fontSize: 20.0,
                              fontWeight: FontWeight.bold
                          )),
                          color: Colors.yellow[700],
                          shape: RoundedRectangleBorder(

                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        )
                      ]
                  ),
                ),
              ),
            ]
        ),
      ),
    );
  }

  Future<void> upload(List<Asset> images) async{
    CircularProgressIndicator(
      backgroundColor: Colors.cyanAccent,
      valueColor: new AlwaysStoppedAnimation<Color>(Colors.red),

    );
    final FirebaseUser user = await _auth.currentUser();
    final userid = user.uid;
    var now = new DateTime.now();
    var formatter = new DateFormat('dd-MM-yyyy');
    String formattedDate = formatter.format(now);
    List<String> imageURLs = [];
    for (int i = 0; i < images.length; i++) {
      final StorageReference storageReference = FirebaseStorage().ref().child("images").child(user.uid.toString()).child(formattedDate).child(material).child(name).child("$i");
      final byteData = await images[i].getByteData();
      final tempFile = File("${(await getTemporaryDirectory()).path}/${images[i].name}");
      final file = await tempFile.writeAsBytes(byteData.buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes),);
      final StorageUploadTask uploadTask = storageReference.putFile(file);
      String imageUrl = await (await uploadTask.onComplete).ref.getDownloadURL();
      imageURLs.add(imageUrl.toString());
    }
    DatabaseReference databaseReference = FirebaseDatabase.instance.reference().child("Data");
    String uploadId = databaseReference.push().key;
    int len = imageURLs.length;
    HashMap map = new HashMap();
    map["name"] = name;
    map["material"] = material;
    map["price"] = price;
    map["subCategory"] = subCategary;
    for(int j=0;j<len;j++)
    {
      if(imageURLs[j]!=null)
        map["imgUrl$j"]=imageURLs[j];
    }
    map["adder"] = currentEmail;
    databaseReference.child(uploadId).set(map);

    route(){
      Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (context) => HomePage(currentEmail)));
    }
    Timer(Duration(seconds: 10), route);

  }
}

