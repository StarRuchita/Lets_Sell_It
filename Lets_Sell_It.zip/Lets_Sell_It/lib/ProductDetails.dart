import 'dart:async';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';



class ProductDetails extends StatefulWidget {
  String product_details_name;
  String product_details_picture0;
  String product_details_picture1;
  String product_details_picture2;
  String product_details_picture3;
  String product_details_price;
  String product_details_adder;
  String upload_id;

  ProductDetails({
    this.product_details_name,
    this.product_details_picture0,
    this.product_details_picture1,
    this.product_details_picture2,
    this.product_details_picture3,
    this.product_details_price,
    this.product_details_adder,
    this.upload_id
  });


  @override
  _ProductDetailsState createState() => _ProductDetailsState(product_details_picture0,product_details_picture1,product_details_picture2,product_details_picture3,upload_id);
}

class _ProductDetailsState extends State<ProductDetails> {
 bool isFav=false;
  FirebaseAuth _auth = FirebaseAuth.instance;

  String product_details_picture0,product_details_picture1,product_details_picture2,product_details_picture3,upload_id;

  _ProductDetailsState(this.product_details_picture0, this.product_details_picture1, this.product_details_picture2, this.product_details_picture3,this.upload_id);

  @override
  void initState(){
    super.initState();

    DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
    referenceData.once().then((DataSnapshot dataSnapShot){
      _auth.currentUser().then((value) {
        DatabaseReference reference = FirebaseDatabase.instance.reference().child("Data").child(upload_id).child("Fav").child(value.uid).child("state");
        reference.once().then((DataSnapshot snapShot){
          if(snapShot.value!=null){
            if(snapShot.value=="true"){
              isFav=true;
            }else{
              isFav=false;
            }
          }else{
            isFav=false;
          }
        });
      });
    });
    Timer(Duration(seconds: 1), (){
      setState(() {
       //
      });
    });


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.1,
        backgroundColor: Colors.orange,
        title: Text('LSit',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
        iconTheme: new IconThemeData(color: Colors.white),
        leading: new IconButton(
          icon: new Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          }
        ),
      ),
      body: Column(
        children: <Widget>[
          Container(
            height: 200,
            child: new Carousel(
                boxFit: BoxFit.cover,
                images: [
                  if(product_details_picture0!=null)
                    Image.network(widget.product_details_picture0),
                  if(product_details_picture1!=null)
                    Image.network(widget.product_details_picture1),
                  if(product_details_picture2!=null)
                    Image.network(widget.product_details_picture2),
                  if(product_details_picture3!=null)
                    Image.network(widget.product_details_picture3),
                ],
                autoplay: true,
                dotSize: 6.0,
                indicatorBgPadding: 3.0,
                animationCurve: Curves.fastOutSlowIn,
                animationDuration: Duration(microseconds: 1000)
            ),
          ),
          SizedBox(height: 10,),
          Container(
            width: double.infinity,
            height: 50,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 5,),
                  Text("Product Name : "+widget.product_details_name, style: TextStyle(color: Colors.black54,fontWeight: FontWeight.bold, fontSize: 15),),
                ],
              ),
            ),
          ),
          Divider(),
          Container(
            width: double.infinity,
            height: 50,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 5,),
                  Text("Product Price : "+widget.product_details_price, style: TextStyle(color: Colors.black54,fontWeight: FontWeight.bold, fontSize: 15),),
                ],
              ),
            ),
          ),
          Divider(),
          Container(
            width: double.infinity,
            height: 50,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 5,),
                  Text("Seller Id : "+widget.product_details_adder, style: TextStyle(color: Colors.black54,fontWeight: FontWeight.bold, fontSize: 15),),
                ],
              ),
            ),
          ),
          Divider(),
      SizedBox(height: 1,),
      Row(
        children: <Widget>[
          isFav?
          IconButton(icon: Icon(Icons.favorite,color: Colors.red,), onPressed: () {
            _auth.currentUser().then((value) {
              DatabaseReference favRef = FirebaseDatabase.instance.reference().child("Data").child(upload_id).child("Fav").child(value.uid).child("state");
              favRef.set("false");
              setState(() {
                FavoriteFunc();
              });
            });
          }):
          IconButton(icon: Icon(Icons.favorite_border), onPressed: (){
            _auth.currentUser().then((value) {
              DatabaseReference favRef = FirebaseDatabase.instance.reference().child("Data").child(upload_id).child("Fav")
                  .child(value.uid).child("state");
              favRef.set("true");
              setState(() {
                FavoriteFunc();
              });

            });
          }),
          ],
          ),
        ],
      ),
    );
  }
  void FavoriteFunc() {
    DatabaseReference referenceData = FirebaseDatabase.instance.reference().child("Data");
    referenceData.once().then((DataSnapshot dataSnapShot){
      _auth.currentUser().then((value) {
        DatabaseReference reference = FirebaseDatabase.instance.reference().child("Data").child(upload_id).child("Fav").child(value.uid).child("state");
        reference.once().then((DataSnapshot snapShot){
          if(snapShot.value!=null){
            if(snapShot.value=="true"){
              isFav=true;
            }else{
              isFav=false;
            }
          }else{
            isFav=false;
          }
        });
      });
    });
    Timer(Duration(seconds: 1), (){
        setState(() {
          //
        });
      });
  }

}




